<?php

// routes/web.php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PelangganController;
use App\Http\Controllers\AuthController;

// Menampilkan daftar pelanggan
Route::get('/pelanggan', [PelangganController::class, 'index'])->name('pelanggan.index');

// Menampilkan form untuk menambahkan pelanggan baru
Route::get('/pelanggan/create', [PelangganController::class, 'create'])->name('pelanggan.create');

// Menyimpan data pelanggan baru
Route::post('/pelanggan', [PelangganController::class, 'store'])->name('pelanggan.store');

// Menampilkan detail pelanggan
Route::get('/pelanggan/{id}', [PelangganController::class, 'show'])->name('pelanggan.show');

// Menampilkan form untuk mengedit pelanggan
Route::get('/pelanggan/{id}/edit', [PelangganController::class, 'edit'])->name('pelanggan.edit');

// Menyimpan perubahan pada pelanggan yang sudah diedit
Route::put('/pelanggan/{id}', [PelangganController::class, 'update'])->name('pelanggan.update');

// Menghapus pelanggan
Route::delete('/pelanggan/{id}', [PelangganController::class, 'destroy'])->name('pelanggan.destroy');

Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

Route::get('/register', [AuthController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [AuthController::class, 'register']);