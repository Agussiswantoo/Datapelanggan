<!-- resources/views/pelanggan/show.blade.php -->

@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Detail Pelanggan</h1>
                <p><strong>Kode Pelanggan:</strong> {{ $pelanggan->kode_pelanggan }}</p>
                <p><strong>Nama Pelanggan:</strong> {{ $pelanggan->nama_pelanggan }}</p>
                <p><strong>Alamat:</strong> {{ $pelanggan->alamat }}</p>
                <p><strong>Kota:</strong> {{ $pelanggan->kota }}</p>
                <p><strong>Provinsi:</strong> {{ $pelanggan->provinsi }}</p>
                <p><strong>Nomer Telepon:</strong> {{ $pelanggan->nomer_telepon }}</p>
                <p><strong>Email:</strong> {{ $pelanggan->email }}</p>
                <p><strong>Kategori Pelanggan:</strong> {{ $pelanggan->kategori_pelanggan }}</p>
                <p><strong>Batas Kredit:</strong> {{ $pelanggan->batas_kredit }}</p>
                <!-- Tampilkan field lain sesuai kebutuhan -->
                <a href="{{ route('pelanggan.index') }}" class="btn btn-secondary">Kembali</a>
            </div>
        </div>
    </div>
@endsection
