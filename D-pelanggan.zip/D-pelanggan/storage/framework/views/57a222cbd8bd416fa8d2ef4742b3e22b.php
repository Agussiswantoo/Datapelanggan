<!-- resources/views/pelanggan/create.blade.php -->



<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Tambah Pelanggan</h1>
                <form action="<?php echo e(route('pelanggan.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="kode_pelanggan">Kode Pelanggan</label>
                        <input type="text" name="kode_pelanggan" id="kode_pelanggan" class="form-control" required>
                    </div>
                    <!-- Tambahkan field lain sesuai kebutuhan -->
                    <div class="form-group">
                        <label for="nama_pelanggan">Nama Pelanggan</label>
                        <input type="text" name="nama_pelanggan" id="nama_pelanggan" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="alamat">Alamat</label>
                        <input type="text" name="alamat" id="alamat" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="kota">Kota</label>
                        <input type="text" name="kota" id="kota" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="provinsi">Provinsi</label>
                        <input type="text" name="provinsi" id="provinsi" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="nomor_telepon">Nomor Telepon</label>
                        <input type="text" name="nomor_telepon" id="nomor_telepon" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="text" name="email" id="email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="kategori_pelanggan">Kategori Pelanggan</label>
                        <input type="text" name="kategori_pelanggan" id="kategori_pelanggan" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="batas_kredit">Batas Kredit</label>
                        <input type="text" name="batas_kredit" id="batas_kredit" class="form-control" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary" onclick="simpanData()">Simpan</button>
                </form>
            </div>
        </div>
    </div>

    <script>
        function simpanData() {
            var newData = document.getElementById("kode_pelanggan").value;
            var newData = document.getElementById("nama_pelanggan").value;
            var newData = document.getElementById("alamat").value;
            var newData = document.getElementById("kota").value;
            var newData = document.getElementById("provinsi").value;
            var newData = document.getElementById("nomor_telepon").value;
            var newData = document.getElementById("email").value;
            var newData = document.getElementById("kategori_pelanggan").value;
            var newData = document.getElementById("batas_kredit").value;
           
            if (existingData.includes(newData)) {
                alert("Data sudah ada!");
            } else {
                // Proses penyimpanan data atau tindakan lainnya jika data belum ada
                // Di sini Anda dapat menambahkan logika untuk menyimpan data ke database atau tempat penyimpanan lainnya
                alert("Data berhasil disimpan:", newData);
            }
        }
    </script>
    
    <style>
        /* Tambahkan CSS sesuai kebutuhan di sini */
        .container {
            margin-top: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #000000;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .btn-primary {
            background-color: #007bff;
            color: #ffffff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
        }

        .btn-primary:hover {
            background-color: #f4f4f4;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\D-pelanggan\resources\views/pelanggan/create.blade.php ENDPATH**/ ?>